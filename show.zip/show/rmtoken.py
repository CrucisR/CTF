import os
import fileinput

# 获取当前工作目录
current_directory = os.getcwd()

# 遍历当前目录下的子文件夹
for subdir, dirs, files in os.walk(current_directory):
    for filename in files:
        # 检查文件是否以.pwn为扩展名
        if filename.endswith("pwn.url"):
            file_path = os.path.join(subdir, filename)
            data = ""
            with open(file_path, "r") as f:
                data = f.read().split("?token")[0]
            with open(file_path, "w") as f:
                f.write(data)
            