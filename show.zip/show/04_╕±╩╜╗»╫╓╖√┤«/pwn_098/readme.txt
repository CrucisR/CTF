Canary？有没有办法绕过呢？

