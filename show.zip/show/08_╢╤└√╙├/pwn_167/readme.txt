10
了解一下large bin吧

远程环境：Ubuntu 16.04