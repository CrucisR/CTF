off by null

远程环境：Ubuntu 18.04