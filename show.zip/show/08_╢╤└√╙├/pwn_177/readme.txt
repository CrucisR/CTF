Ez note

远程环境：Ubuntu 16.04