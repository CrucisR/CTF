给你一个shell，这次需要你自己去获得flag

