用户名为 ctfshow 密码 为 123456 请使用 ssh软件连接

ssh ctfshow@题目地址 -p题目端口号
不是nc连接