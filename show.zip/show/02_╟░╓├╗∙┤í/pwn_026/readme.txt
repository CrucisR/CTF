设置好 ALSR 保护参数值即可获得flag

为确保flag正确，本题建议用提供虚拟机运行

libc下载地址
https://pan.baidu.com/s/1aBhaQfgcw4m2ut6ybNOBmA

提取码为： show