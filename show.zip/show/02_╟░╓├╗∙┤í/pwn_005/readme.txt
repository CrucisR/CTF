运行此文件，将得到的字符串以ctfshow{xxxxx}提交。

如：运行文件后 输出的内容为 Hello_World

提交的flag值为：ctfshow{Hello_World}

注：计组原理题型后续的flag中地址字母大写