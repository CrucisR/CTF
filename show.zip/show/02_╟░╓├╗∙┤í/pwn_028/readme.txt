设置好 ALSR 保护参数值即可获得flag

libc下载地址
https://pan.baidu.com/s/1aBhaQfgcw4m2ut6ybNOBmA

提取码为： show