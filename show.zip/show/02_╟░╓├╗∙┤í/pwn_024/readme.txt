你可以使用pwntools的shellcraft模块来进行攻击

