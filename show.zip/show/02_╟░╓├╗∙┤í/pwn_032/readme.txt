FORTIFY_SOURCE=0：

禁用 Fortify 功能。 不会进行任何额外的安全检查。 可能导致潜在的安全漏洞。