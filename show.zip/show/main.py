import os

pre_folder_name = 'pwn'
for i in range(205,205+1):
    new_folder = pre_folder_name+f'_{i:03d}'
    os.makedirs(new_folder, exist_ok=True)
    with open(new_folder+"/readme.txt", 'w') as file:
        pass

"""
0,4
5,34
35,80
91,100
101,110
111,134
135,159
160,180
181,204
205
"""