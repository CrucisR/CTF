fastbin_dup_into_stack

