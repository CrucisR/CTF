fastbin_dup

