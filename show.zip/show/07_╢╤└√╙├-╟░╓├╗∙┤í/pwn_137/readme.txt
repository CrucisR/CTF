sbrk and brk example

