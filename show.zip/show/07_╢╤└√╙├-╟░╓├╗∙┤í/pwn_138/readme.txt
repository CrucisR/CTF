Private anonymous mapping exampl

