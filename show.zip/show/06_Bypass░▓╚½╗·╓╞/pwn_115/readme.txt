Bypass Canary 姿势1

