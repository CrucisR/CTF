Calc 2.0

远程环境：Ubuntu 16.04