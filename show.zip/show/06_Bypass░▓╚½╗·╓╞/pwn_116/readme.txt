Bypass Canary 姿势2

