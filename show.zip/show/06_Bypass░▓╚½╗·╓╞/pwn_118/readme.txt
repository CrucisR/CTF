Bypass Canary 姿势4

