Bypass Canary 姿势8

远程环境：Ubuntu 16