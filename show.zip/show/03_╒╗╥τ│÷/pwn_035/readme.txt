正式开始栈溢出了，先来一个最最最最简单的吧

用户名为 ctfshow 密码 为 123456 请使用 ssh软件连接

ssh ctfshow@题目地址 -p题目端口号
不是nc连接

专用虚拟机镜像，全套在这里，提取码show
https://pan.baidu.com/s/1wHPhZ7XOouFU6KgyOiSfLQ