64位的 system(“/bin/sh”) 后门函数给你

