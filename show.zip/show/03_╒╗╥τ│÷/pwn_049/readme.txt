静态编译？或许你可以找找mprotect函数

