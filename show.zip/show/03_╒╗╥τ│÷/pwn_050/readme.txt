好像哪里不一样了

远程libc环境 Ubuntu 18