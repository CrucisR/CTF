接着练ret2syscall，多系统函数调用

