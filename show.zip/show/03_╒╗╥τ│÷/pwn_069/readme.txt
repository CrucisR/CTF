可以尝试用ORW读flag flag文件位置为/ctfshow_flag

