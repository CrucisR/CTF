ROP变种

